package ai.tar.agentos

class ActionExecutor {
    fun execute(action: String) {
        // TODO: execute action
    }
}
