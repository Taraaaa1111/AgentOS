package ai.tar.agentos

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class UiControlAccessibility : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // TODO: handle UI events
    }

    override fun onInterrupt() {
        // Required override
    }
}
