package ai.tar.agentos

class ScreenshotProvider {
    fun capture() {
        // TODO: screenshot logic
    }
}
